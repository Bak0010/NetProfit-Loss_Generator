﻿Imports System.IO
Public Class Form2
    Dim pass As String
    Private Sub Form2_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        ControlPaint.DrawBorder(e.Graphics, e.ClipRectangle, Color.Black, ButtonBorderStyle.Solid)
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim password As String
        password = txtpass.Text
        Try
            Dim passwordfile As StreamReader = File.OpenText("password.txt")
            password = txtpass.Text
            If password = passwordfile.ReadLine Then
                Form1.Show()
                Me.Hide()
            Else
                MsgBox("Wrong Password!")
                txtpass.Clear()
                txtpass.Focus()
            End If
            passwordfile.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
            MessageBox.Show("The program will now exit.")
            Me.Close()
        End Try
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Size = New Size(391, 361)
        Dim passwordfile2 As StreamReader = New StreamReader("password.txt")
        pass = passwordfile2.ReadLine()
        passwordfile2.Close()
    End Sub

    Private Sub btnForgot_Click(sender As Object, e As EventArgs) Handles btnForgot.Click
        If Val(Me.Height) = (361) Then
            Me.Size = New Size(391, 601)
        Else Me.Size = New Size(391, 361)
        End If
    End Sub

    Private Sub btnChange_Click(sender As Object, e As EventArgs) Handles btnChange.Click
        Dim old, new1, new2 As String

        old = txtOldpass.Text
        new1 = txtNewpass.Text
        new2 = txtNewpass2.Text

        Try
            If old = pass Then

            End If
            If new1 = new2 Then
                Dim newpassword As StreamWriter = File.CreateText("password.txt")
                MsgBox("Your password has been successfully changed")
                Me.Size = New Size(500, 457)
                pass = new1

                Dim sourcetext, encryptedtext, character As String
                Dim temp, loops As Integer
                sourcetext = pass
                For loops = 1 To Len(sourcetext)
                    character = Mid(sourcetext, loops, 1)
                    temp = Asc(character) + 13
                    encryptedtext = encryptedtext & Chr(temp)
                Next
                newpassword.WriteLine(encryptedtext, 0)
                newpassword.Close()
            Else MsgBox("You have entered an incorrect password")
            End If
        Catch ex As Exception
            MsgBox("Could not find the file")
        End Try
    End Sub
End Class