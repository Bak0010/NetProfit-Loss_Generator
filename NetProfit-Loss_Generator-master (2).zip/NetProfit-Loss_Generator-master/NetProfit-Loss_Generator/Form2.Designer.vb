﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtNewpass2 = New System.Windows.Forms.TextBox()
        Me.txtNewpass = New System.Windows.Forms.TextBox()
        Me.txtOldpass = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnForgot = New System.Windows.Forms.Button()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.txtpass = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblPromt = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnChange = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtNewpass2
        '
        Me.txtNewpass2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNewpass2.Location = New System.Drawing.Point(200, 418)
        Me.txtNewpass2.Name = "txtNewpass2"
        Me.txtNewpass2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtNewpass2.Size = New System.Drawing.Size(119, 26)
        Me.txtNewpass2.TabIndex = 24
        Me.txtNewpass2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtNewpass
        '
        Me.txtNewpass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNewpass.Location = New System.Drawing.Point(200, 380)
        Me.txtNewpass.Name = "txtNewpass"
        Me.txtNewpass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtNewpass.Size = New System.Drawing.Size(119, 26)
        Me.txtNewpass.TabIndex = 23
        Me.txtNewpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtOldpass
        '
        Me.txtOldpass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOldpass.Location = New System.Drawing.Point(129, 348)
        Me.txtOldpass.Name = "txtOldpass"
        Me.txtOldpass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtOldpass.Size = New System.Drawing.Size(119, 26)
        Me.txtOldpass.TabIndex = 22
        Me.txtOldpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("MS Reference Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(67, 420)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(127, 21)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Enter Password:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("MS Reference Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(109, 324)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(156, 21)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Enter Old Password:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS Reference Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(67, 382)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(127, 21)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Enter Password:"
        '
        'btnForgot
        '
        Me.btnForgot.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnForgot.Font = New System.Drawing.Font("MS Reference Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnForgot.ForeColor = System.Drawing.SystemColors.Control
        Me.btnForgot.Location = New System.Drawing.Point(125, 246)
        Me.btnForgot.Name = "btnForgot"
        Me.btnForgot.Size = New System.Drawing.Size(123, 35)
        Me.btnForgot.TabIndex = 17
        Me.btnForgot.Text = "Forgot Password?"
        Me.btnForgot.UseVisualStyleBackColor = False
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnLogin.ForeColor = System.Drawing.SystemColors.Control
        Me.btnLogin.Location = New System.Drawing.Point(125, 195)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(123, 35)
        Me.btnLogin.TabIndex = 16
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = False
        '
        'txtpass
        '
        Me.txtpass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpass.Location = New System.Drawing.Point(129, 140)
        Me.txtpass.Name = "txtpass"
        Me.txtpass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtpass.Size = New System.Drawing.Size(119, 26)
        Me.txtpass.TabIndex = 15
        Me.txtpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS Reference Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(125, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(127, 21)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Enter Password:"
        '
        'lblPromt
        '
        Me.lblPromt.AutoSize = True
        Me.lblPromt.Font = New System.Drawing.Font("MS Reference Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPromt.Location = New System.Drawing.Point(140, 25)
        Me.lblPromt.Name = "lblPromt"
        Me.lblPromt.Size = New System.Drawing.Size(94, 33)
        Me.lblPromt.TabIndex = 13
        Me.lblPromt.Text = "Log In"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Label1.Location = New System.Drawing.Point(54, -9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(280, 595)
        Me.Label1.TabIndex = 18
        '
        'btnChange
        '
        Me.btnChange.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnChange.ForeColor = System.Drawing.SystemColors.Control
        Me.btnChange.Location = New System.Drawing.Point(125, 490)
        Me.btnChange.Name = "btnChange"
        Me.btnChange.Size = New System.Drawing.Size(123, 35)
        Me.btnChange.TabIndex = 25
        Me.btnChange.Text = "Change Password"
        Me.btnChange.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(389, 577)
        Me.Controls.Add(Me.btnChange)
        Me.Controls.Add(Me.txtNewpass2)
        Me.Controls.Add(Me.txtNewpass)
        Me.Controls.Add(Me.txtOldpass)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnForgot)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.txtpass)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblPromt)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtNewpass2 As TextBox
    Friend WithEvents txtNewpass As TextBox
    Friend WithEvents txtOldpass As TextBox
    Private WithEvents Label5 As Label
    Private WithEvents Label4 As Label
    Private WithEvents Label3 As Label
    Friend WithEvents btnForgot As Button
    Friend WithEvents btnLogin As Button
    Friend WithEvents txtpass As TextBox
    Private WithEvents Label2 As Label
    Friend WithEvents lblPromt As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnChange As Button
End Class
